import React from 'react'

function Timeout_1() {
  return (
    <div>
        <h1>Room has expired!!!!!!!!!!!!!!</h1>
    </div>
  )
}

export default Timeout_1