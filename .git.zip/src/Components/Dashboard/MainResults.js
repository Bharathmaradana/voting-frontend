import React from "react";
import { Result } from "./Results";

function MainResults() {
  return (
    <div>
      <h1
        style={{
          backgroundColor: "white",
          color: "white",
          zIndex: "1000000000000000000",
          marginTop: "10%",
        }}
      >
        something i want toknow about this
      </h1>
      <div style={{ height: "30px" }}>
        <Result />
      </div>
    </div>
  );
}

export default MainResults;
